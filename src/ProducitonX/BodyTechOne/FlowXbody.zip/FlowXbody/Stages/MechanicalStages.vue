<script setup>
</script>
<template>
    <p>Mechanical </p>
</template>