<script setup>
</script>
<template>
    <p>paint </p>
</template>