<script setup>
</script>
<template>
    <p>Parts delivert</p>
</template>