<script setup>
</script>
<template>
    <p>PartsHoldStages</p>
</template>