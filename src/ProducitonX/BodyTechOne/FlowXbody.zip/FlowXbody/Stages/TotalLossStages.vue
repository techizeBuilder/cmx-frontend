<script setup>
</script>
<template>
    <p>Total Losss</p>
</template>