<script setup>
</script>
<template>
    <p>Frame  </p>
</template>