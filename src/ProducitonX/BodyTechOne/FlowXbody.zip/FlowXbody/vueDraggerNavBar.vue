<script setup>
import flexIcon from "../../Icons/flexIcon.png";
import Uplaod from "../../Icons/Uplaod.png";
import Photor from "../../Icons/Photor.png";
import FileAx from "../../Icons/FileAx.png";
import printAX from "../../Icons/printAX.png";
import ChatAx from "../../Icons/ChatAx.png";
import FIcon from "../../Icons/FIcon.png";
import { ref, watch } from "vue";

const props = defineProps(["itemData"]);
const isDraggable = ref(props.itemData.isDraggable);
const emit = defineEmits(["handleDragable"]);
const handleDragable = () => {
  emit("handleDragable");
  isDraggable.value = !isDraggable.value;
};
watch(props, () => {
  isDraggable.value = props.itemData.isDraggable;
});
const element = ref(props.itemData.element);
const index = ref(props.itemData.index);
</script>
<template>
  <div
    class="topVgZ d-flex justify-content-between"
    :style="{ backgroundColor: element.Color }"
  >
    <div class="d-flex gap-3 align-items-center">
      <span class="StagNum">{{ index + 1 }}</span>
      <div class="tooltips">
        <img class="cursor-pointer" :src="Uplaod" alt="Uplaod" />
        <span class="tooltiptext">Open FoldX </span>
      </div>
      <div class="tooltips">
        <img
          class="cursor-pointer"
          data-bs-toggle="modal"
          data-bs-target="#PhotoViewModul"
          :src="Photor"
          alt="Photor"
        />
        <span class="tooltiptext">View Photos </span>
      </div>
      <div class="tooltips">
        <img class="cursor-pointer" :src="FileAx" alt="FileAx" />
        <span class="tooltiptext">View Estimate </span>
      </div>
      <div class="tooltips">
        <img class="cursor-pointer" :src="printAX" alt="printAX" />
        <span class="tooltiptext">Print File </span>
      </div>

      <div class="tooltips">
        <img
          class="cursor-pointer"
          data-bs-toggle="modal"
          data-bs-target="#TimelineModul"
          :src="ChatAx"
          alt="ChatAx"
        />
        <span class="tooltiptext">Timeline </span>
      </div>
      <div class="tooltips">
        <img class="cursor-pointer" :src="FIcon" alt="FIcon" />
        <span class="tooltiptext">Flag Tech </span>
      </div>
    </div>
    <div>
      <i
        class="fa-solid fa-grip-vertical"
        role="button"
        @click="handleDragable"
        :style="{
          color: isDraggable ? '#0066ee' : null,
        }"
      ></i>
    </div>
  </div>
</template>
<style scoped>
.FlowXbody ul.link-section .li-drop .accomdationset-head h3 {
  text-wrap: nowrap;
}

p.NumTos.m-0 {
  width: 26px;
  height: 20px;
  background-color: #eeeeee;
  text-align: center;
  border-radius: 4px;
  vertical-align: middle;
  font-size: 13px;
  font-weight: 600;
}

.pages:before {
  content: "";
  position: absolute;
  left: -20px;
  height: 100%;
  width: 20px;
  z-index: 99;
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}

.ComeBackA:before {
  border-left: 11px solid #cfaf00;
}

.ArrivalA:before {
  border-left: 11px solid #c0ffb5;
}

.RepairPlanA:before {
  border-left: 11px solid #fff975;
}

.SupplementHoldA:before {
  border-left: 11px solid #ffc487;
}

.SupplementApprovedA:before {
  border-left: 11px solid #ff8200;
}

.PartsHoldStagesA:before {
  border-left: 11px solid #cecece;
}

.PartsDeliveredStagesA:before {
  border-left: 11px solid #787878;
}

.BodyStagesA:before {
  border-left: 11px solid #adcdff;
}

.FrameStagesA:before {
  border-left: 11px solid #adcdff;
}

.MechanicalStagesA:before {
  border-left: 11px solid #adcdff;
}

.SubletOffsiteStagesA:before {
  border-left: 11px solid #adcdff;
}

.ExpressBodyStagesA:before {
  border-left: 11px solid #0ff;
}

.ExpressPaintStagesA:before {
  border-left: 11px solid #0ff;
}

.PaintStagesA:before {
  border-left: 11px solid #0ff;
}

.ReassemblyStagesA:before {
  border-left: 11px solid #3685ff;
}

.ADASStagesA:before {
  border-left: 11px solid #e69b7a;
}

.DetailStagesA:before {
  border-left: 11px solid #b947ff;
}

.CompletedStagesA:before {
  border-left: 11px solid #027a2b;
}

.TotalLossStagesA:before {
  border-left: 11px solid #d30e0e;
}

.tooltips {
  position: relative;
}

.tooltips .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;
  font-size: 14px;

  /* Position the tooltip */
  position: absolute;
  z-index: 1;
  top: 100%;
  left: 50%;
  margin-left: -60px;
}

.tooltips:hover .tooltiptext {
  visibility: visible;
}

.pTableFlow {
  border-radius: 3px;
}

.pTableFlow table.table td {
  font-size: 16px;
}

.boxAX {
  border-radius: 5px 5px 5px 5px;
  border: 1px solid #cacaca;
  background: #fff;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
}

.topVgZ {
  padding: 4px 5px;
  border-top-right-radius: 5px;
  border-top-left-radius: 5px;
}

.StagNum {
  border-radius: 5px;
  text-align: center;
  width: 30px;
  height: 25px;
  background-color: transparent;
  border: 1px solid #000;
  font-weight: 600;
}

.StagNum:hover {
  box-shadow: none;
}

input.StagNum:focus,
.StagNum:focus-visible {
  box-shadow: none;
  outline: none;
}

.list-group-item {
  border: none;
}
</style>
