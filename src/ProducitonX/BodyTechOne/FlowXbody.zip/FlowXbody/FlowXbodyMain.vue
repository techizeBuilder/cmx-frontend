<script setup>
import ComeBack from "./Stages/ComeBack.vue";
import ArrivalStages from "./Stages/ArrivalStages.vue";
import RepairPlanStages from "./Stages/RepairPlanStages.vue";
import SupplementHoldStages from "./Stages/SupplementHoldStages.vue";
import SupplementApprovedStages from "./Stages/SupplementApprovedStages.vue";
import PartsHoldStages from "./Stages/PartsHoldStages.vue";
import PartsDeliveredStages from "./Stages/PartsDeliveredStages.vue";
import BodyStages from "./Stages/BodyStages.vue";
import FrameStages from "./Stages/FrameStages.vue";
import MechanicalStages from "./Stages/MechanicalStages.vue";
import SubletOffsiteStages from "./Stages/SubletOffsiteStages.vue";
import ExpressBodyStages from "./Stages/ExpressBodyStages.vue";
import ExpressPaintStages from "./Stages/ExpressPaintStages.vue";
import PaintStages from "./Stages/PaintStages.vue";
import ReassemblyStages from "./Stages/ReassemblyStages.vue";
import DetailStages from "./Stages/DetailStages.vue";
import CompletedStages from "./Stages/CompletedStages.vue";
import TotalLossStages from "./Stages/TotalLossStages.vue";
import ADASStages from "./Stages/ADASStages.vue";

import cmx from "../../Icons/cmx.jpeg";
import flexIcon from "../../Icons/flexIcon.png";
import Uplaod from "../../Icons/Uplaod.png";
import Photor from "../../Icons/Photor.png";
import FileAx from "../../Icons/FileAx.png";
import printAX from "../../Icons/printAX.png";
import ChatAx from "../../Icons/ChatAx.png";
import FIcon from "../../Icons/FIcon.png";
import OffIcons from "../../Icons/OffIcons.png";

import NumImg from "../../Icons/NumImg.png";
import DropdownAX from "../../Icons/DropdownAX.png";
import vueDraggerData from "./vueDraggerData.vue";

import TimelineModul from "./Stages/TimelineModul.vue";
import PhotoViewModul from "./Stages/PhotoViewModul.vue";
import { Swiper, SwiperSlide } from "swiper/vue";
import { Navigation, A11y } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import { ref } from "vue";
const modules = [Navigation, A11y];
</script>
<script>
import vuedraggable from "vuedraggable";

export default {
  name: "two-list-headerslots",
  display: "Two list header slot",
  order: 14,
  components: {
    vuedraggable,
  },
  data() {
    return {
      ComeBackData: [
        {
          id: 1,
          Color: "#cfaf00",
          floderX: "XXXXXX001",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "Make",
          Model: "Model",
          LastName: "Last Name",
          FirstName: "First Name",
          Insurance: "Insurance",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
        {
          id: 2,
          Color: "#cfaf00",
          floderX: "XXXXXX002",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "Make",
          Model: "Model",
          LastName: "LastName",
          FirstName: "FirstName",
          Insurance: "Insurance",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
      ],
      ArrivalData: [
        {
          id: 3,
          Color: "#c0ffb5",
          floderX: "XXXXXX003",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
        {
          id: 4,
          Color: "#c0ffb5",
          floderX: "XXXXXX004",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
      ],
      RepairPlanData: [
        {
          id: 5,
          Color: "#FFF975",
          floderX: "XXXXXX005",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
        {
          id: 6,
          Color: "#FFF975",
          floderX: "XXXXXX006",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
      ],
      SupplementHoldData: [
        {
          id: 7,
          Color: "#FFC487",
          floderX: "XXXXXX007",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
        {
          id: 8,
          Color: "#FFC487",
          floderX: "XXXXXX008",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
      ],
      SupplementApproved: [
        {
          id: 9,
          Color: "#FF8200",
          floderX: "XXXXXX007",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
        {
          id: 10,
          Color: "#FF8200",
          floderX: "XXXXXX008",
          STAGE: "",
          Target: "25/01/2024",
          DaystoRepair: "001",
          Arrival: "MM/DD/YYYY HH:MM PM",
          Completed: "MM/DD/YYYY",
          YYYY: "YYYY ",
          Make: "",
          Model: "",
          LastName: "",
          FirstName: "",
          Insurance: "",
          Estimator: "Full Name",
          BodyTech: "Full Name",
          PaintTech: "Full Name",
          FrameTech: "Full Name",
          MechTech: "Full Name",
          DetailTech: "Full Name",
          PreScan: "-",
          PostScan: "-",
          ADAS: "-",
          EstimateAmount: "$00,000.00",
          TotalHrs: "28.5",
          Body: "14.0",
          Mech: "2.0",
          Frame: "4.5",
          Paint: "8.0",
          TotalParts: "005",
          Ordered: "002",
          Delivered: "003",
        },
      ],
    };
  },
};
const colorChage = (e, list) => {
  console.log(e);
  console.log(list);
};
const isDraggable = ref(false);
const handleDragable = () => {
  isDraggable.value = !isDraggable.value;
};

const positions = ref({});
</script>
<template>
  <div class="FlowXbody">
    <div id="manishs" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="row px-5">
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div class="accordion accordion-flush" id="accordionComeBack">
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages ComeBackA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapsecmsComeBack"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Come Back</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapsecmsComeBack"
                        class="accordion-collapse collapse show show"
                        data-bs-parent="#accordionComeBack"
                        :style="{ minWidth: '350px', zIndex: '9999999' }"
                      >
                        <vuedraggable
                          id="first"
                          :disabled="!isDraggable"
                          @change="colorChage"
                          data-source="juju"
                          :list="ComeBackData"
                          class="list-group manish"
                          group="a"
                          item-key="name"
                          style="z-index: 9999999;"
                        >
                          <template #item="{ element, index }">
                            <vueDraggerData
                              :itemData="{
                                element: element,
                                index: index,
                                isDraggable: isDraggable,
                              }"
                              @handleDragable="handleDragable"
                            />
                          </template>
                        </vuedraggable>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionArrivalAXD"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages ArrivalA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapsecmsArrivalAXD"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ArrivalData.length }}</p>
                            <h3>Arrival</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapsecmsArrivalAXD"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionArrivalAXD"
                        :style="{ minWidth: '350px' }"
                      >
                        <vuedraggable
                          id="first"
                          data-source="juju"
                          :list="ArrivalData"
                          class="list-group"
                          group="a"
                          item-key="name"
                          :disabled="!isDraggable"
                        >
                          <template #item="{ element, index }">
                            <vueDraggerData
                              :itemData="{
                                element: element,
                                index: index,
                                isDraggable: isDraggable,
                              }"
                              @handleDragable="handleDragable"
                            />
                          </template>
                        </vuedraggable>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionRepairPlan"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages RepairPlanA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseRepairPlan"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">
                              {{ RepairPlanData.length }}
                            </p>
                            <h3>Repair Plan</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseRepairPlan"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionRepairPlan"
                        :style="{ minWidth: '350px' }"
                      >
                        <vuedraggable
                          id="first"
                          data-source="juju"
                          :list="RepairPlanData"
                          class="list-group"
                          group="a"
                          item-key="name"
                          :disabled="!isDraggable"
                        >
                          <template #item="{ element, index }">
                            <vueDraggerData
                              :itemData="{
                                element: element,
                                index: index,
                                isDraggable: isDraggable,
                              }"
                              @handleDragable="handleDragable"
                            />
                          </template>
                        </vuedraggable>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row px-5">
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionSupplementHoldStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages SupplementHoldA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseSupplementHoldStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">
                              {{ SupplementHoldData.length }}
                            </p>
                            <h3>Supplement Hold</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseSupplementHoldStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionSupplementHoldStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <vuedraggable
                          id="first"
                          data-source="juju"
                          :list="SupplementHoldData"
                          class="list-group"
                          group="a"
                          item-key="name"
                          :disabled="!isDraggable"
                        >
                          <template #item="{ element, index }">
                            <vueDraggerData
                              :itemData="{
                                element: element,
                                index: index,
                                isDraggable: isDraggable,
                              }"
                              @handleDragable="handleDragable"
                            />
                          </template>
                        </vuedraggable>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionSupplementApprovedStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages SupplementApprovedA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseSupplementApprovedStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">
                              {{ SupplementApproved.length }}
                            </p>
                            <h3>Supplement Approved</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseSupplementApprovedStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionSupplementApprovedStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <vuedraggable
                          id="first"
                          data-source="juju"
                          :list="SupplementApproved"
                          class="list-group"
                          group="a"
                          item-key="name"
                          :disabled="!isDraggable"
                        >
                          <template #item="{ element, index }">
                            <vueDraggerData
                              :itemData="{
                                element: element,
                                index: index,
                                isDraggable: isDraggable,
                              }"
                              @handleDragable="handleDragable"
                            />
                          </template>
                        </vuedraggable>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionPartsHoldStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages PartsHoldStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapsePartsHoldStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">1</p>
                            <h3>Parts Hold</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapsePartsHoldStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionPartsHoldStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <PartsHoldStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row px-5">
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionPartsDeliveredStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages PartsDeliveredStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapsePartsDeliveredStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Parts Delivered</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapsePartsDeliveredStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionPartsDeliveredStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <PartsDeliveredStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionBodyStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages BodyStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseBodyStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Body</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseBodyStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionBodyStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <BodyStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionFrameStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages FrameStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseFrameStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Frame</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseFrameStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionFrameStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <FrameStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row px-5">
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionMechanicalStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages MechanicalStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseMechanicalStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Mechanical</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseMechanicalStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionMechanicalStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <MechanicalStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionSubletOffsiteStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages SubletOffsiteStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseSubletOffsiteStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Sublet | Offsite</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseSubletOffsiteStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionSubletOffsiteStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <SubletOffsiteStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionExpressBodyStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages ExpressBodyStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseExpressBodyStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Express Body</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseExpressBodyStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionExpressBodyStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <ExpressBodyStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row px-5">
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionExpressPaintStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages ExpressPaintStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseExpressPaintStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Express Paint</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseExpressPaintStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionExpressPaintStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <ExpressPaintStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionPaintStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages PaintStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapsePaintStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Paint</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapsePaintStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionPaintStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <PaintStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionReassemblyStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages ReassemblyStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseReassemblyStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Reassembly</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseReassemblyStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionReassemblyStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <ReassemblyStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row px-5">
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionADASStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages ADASStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseADASStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>ADAS</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseADASStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionADASStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <ADASStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionDetailStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages DetailStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseDetailStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Detail</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseDetailStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionDetailStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <DetailStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-sm-4">
              <ul class="link-section">
                <li class="li-drop">
                  <div
                    class="accordion accordion-flush"
                    id="accordionCompletedStages"
                  >
                    <div
                      class="accordion-item"
                      :style="{
                        maxHeight: '800px',
                        overflow: 'auto',
                        position: 'relative',
                      }"
                    >
                      <div class="pages CompletedStagesA">
                        <div
                          class="accordion-button collapsed folderXAccor"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseCompletedStages"
                          aria-expanded="true"
                        >
                          <div
                            class="accomdationset-head"
                            :style="{ gap: '20px', marginLeft: '35px' }"
                          >
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Completed</h3>
                          </div>
                        </div>
                      </div>
                      <div
                        id="flush-collapseCompletedStages"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#accordionCompletedStages"
                        :style="{ minWidth: '350px' }"
                      >
                        <CompletedStages />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- <div class="carousel-item">
          <div class='row px-5'>
            <div class='col-sm-12'>
              <ul class="link-section">
                <li class="li-drop">
                  <div class="accordion accordion-flush" id="accordionTotalLossStages">
                    <div class="accordion-item" :style="{
                      maxHeight: '800px',
                      overflow: 'auto',
                      position: 'relative',
                    }">
                      <div class="pages TotalLossStagesA">
                        <div class="accordion-button collapsed folderXAccor" type="button" data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseTotalLossStages" aria-expanded="true">
                          <div class="accomdationset-head" :style="{ gap: '20px', marginLeft: '35px' }">
                            <p class="NumTos m-0">{{ ComeBackData.length }}</p>
                            <h3>Total Loss</h3>
                          </div>
                        </div>
                      </div>
                      <div id="flush-collapseTotalLossStages" class="accordion-collapse collapse show"
                        data-bs-parent="#accordionTotalLossStages" :style="{ minWidth: '350px' }">
                        <TotalLossStages />
                        <PhotoViewModul />
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div> -->
      </div>
      <button
        class="carousel-control-prev"
        type="button"
        data-bs-target="#manishs"
        data-bs-slide="prev"
        style="width: auto; height: auto; padding: 5px;"
      >
        <span class="carousel-control-prev-icon"
          ><i
            class="fa-solid fa-arrow-left"
            :style="{
              color: '#0066ee',
            }"
          ></i
        ></span>
      </button>
      <button
        class="carousel-control-next"
        type="button"
        data-bs-target="#manishs"
        data-bs-slide="next"
        style="width: auto; height: auto; padding: 5px;"
      >
        <span class="carousel-control-next-icon"
          ><i
            class="fa-solid fa-arrow-right"
            :style="{
              color: '#0066ee',
            }"
          ></i
        ></span>
      </button>
    </div>
  </div>
  <TimelineModul :position="positions" />
</template>
<style scoped>
.FlowXbody ul.link-section .li-drop .accomdationset-head h3 {
  text-wrap: nowrap;
}

p.NumTos.m-0 {
  width: 26px;
  height: 20px;
  background-color: #eeeeee;
  text-align: center;
  border-radius: 4px;
  vertical-align: middle;
  font-size: 13px;
  font-weight: 600;
}

.pages:before {
  content: "";
  position: absolute;
  left: -20px;
  height: 100%;
  width: 20px;
  z-index: 99;
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}

.ComeBackA:before {
  border-left: 11px solid #cfaf00;
}

.ArrivalA:before {
  border-left: 11px solid #c0ffb5;
}

.RepairPlanA:before {
  border-left: 11px solid #fff975;
}

.SupplementHoldA:before {
  border-left: 11px solid #ffc487;
}

.SupplementApprovedA:before {
  border-left: 11px solid #ff8200;
}

.PartsHoldStagesA:before {
  border-left: 11px solid #cecece;
}

.PartsDeliveredStagesA:before {
  border-left: 11px solid #787878;
}

.BodyStagesA:before {
  border-left: 11px solid #adcdff;
}

.FrameStagesA:before {
  border-left: 11px solid #adcdff;
}

.MechanicalStagesA:before {
  border-left: 11px solid #adcdff;
}

.SubletOffsiteStagesA:before {
  border-left: 11px solid #adcdff;
}

.ExpressBodyStagesA:before {
  border-left: 11px solid #0ff;
}

.ExpressPaintStagesA:before {
  border-left: 11px solid #0ff;
}

.PaintStagesA:before {
  border-left: 11px solid #0ff;
}

.ReassemblyStagesA:before {
  border-left: 11px solid #3685ff;
}

.ADASStagesA:before {
  border-left: 11px solid #e69b7a;
}

.DetailStagesA:before {
  border-left: 11px solid #b947ff;
}

.CompletedStagesA:before {
  border-left: 11px solid #027a2b;
}

.TotalLossStagesA:before {
  border-left: 11px solid #d30e0e;
}

.tooltips {
  position: relative;
}

.tooltips .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;
  font-size: 14px;

  /* Position the tooltip */
  position: absolute;
  z-index: 1;
  top: 100%;
  left: 50%;
  margin-left: -60px;
}

.tooltips:hover .tooltiptext {
  visibility: visible;
}

.pTableFlow {
  border-radius: 3px;
}

.pTableFlow table.table td {
  font-size: 16px;
}

.boxAX {
  border-radius: 5px 5px 5px 5px;
  border: 1px solid #cacaca;
  background: #fff;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
}

.topVgZ {
  padding: 4px 5px;
  border-top-right-radius: 5px;
  border-top-left-radius: 5px;
}

.StagNum {
  border-radius: 5px;
  text-align: center;
  width: 30px;
  height: 25px;
  background-color: transparent;
  border: 1px solid #000;
  font-weight: 600;
}

.StagNum:hover {
  box-shadow: none;
}

input.StagNum:focus,
.StagNum:focus-visible {
  box-shadow: none;
  outline: none;
}

.list-group-item {
  border: none;
}
</style>
