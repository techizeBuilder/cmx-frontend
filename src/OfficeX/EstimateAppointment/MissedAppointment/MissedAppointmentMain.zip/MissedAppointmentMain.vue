<script setup>
import { ref, watch, computed } from "vue";
import VueDatePicker from "@vuepic/vue-datepicker";
import "@vuepic/vue-datepicker/dist/main.css";

import moment from "moment";

import Estim from "../../Icons/Estim.svg";

const isSaturdayClosed = ref(false);
const isSundayClosed = ref(false);
const selectedDuration = ref(1);
const todayDate = new Date();
const date = ref([moment(todayDate).day(0), moment(todayDate).day(6)]);

const timeArray = computed(() => {
  const array = [];
  for (let hour = 8; hour <= 20; hour++) {
    array.push({ value: hour });
  }
  return array;
});

const events = ref([
  {
    id: 1,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-17T08:08:00.000Z",
    endDate: "2024-02-17T09:08:00.000Z",
    backgroundColor: "#CFAF00",
    category: "Come Back",
  },
  {
    id: 2,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-17T09:08:00.000Z",
    endDate: "2024-02-17T10:08:00.000Z",
    backgroundColor: "#C0FFB5",
    category: "Arrived",
  },
  {
    id: 3,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-17T10:08:00.000Z",
    endDate: "2024-02-17T11:08:00.000Z",
    backgroundColor: "#FFF975",
    category: "Repair Plan",
  },
  {
    id: 4,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-18T18:08:00.000Z",
    endDate: "2024-02-18T18:08:00.000Z",
    backgroundColor: "#FFC487",
    category: "Supplement Hold",
  },
  {
    id: 5,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-18T08:08:00.000Z",
    endDate: "2024-02-18T09:08:00.000Z",
    backgroundColor: "#FF8200",
    category: "Supplement Approved",
  },
  {
    id: 6,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-18T15:09:00.000Z",
    endDate: "2024-02-18T15:10:00.000Z",
    backgroundColor: "#D30E0E",
    category: "Parts Hold",
  },
  {
    id: 7,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-19T15:08:00.000Z",
    endDate: "2024-02-19T15:08:00.000Z",
    backgroundColor: "#027A2B",
    category: "Parts Delivered",
  },
  {
    id: 8,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-19T18:08:00.000Z",
    endDate: "2024-02-19T18:08:00.000Z",
    backgroundColor: "#787878",
    category: "Body | Frame | Mech",
  },
  {
    id: 9,
    folder: "<FolderX#>",
    insurance: "<insurance>",
    name: "<Last, First Name>",
    date: "<YYYY,MAKE,MODEL>",
    body: "B:<Body Tech Name>",
    startDate: "2024-02-20T20:08:00.000Z",
    endDate: "2024-02-20T12:08:00.000Z",
    backgroundColor: "#4D93FF",
    category: "sublet | offsite",
  },
]);
const dynEvents = ref(
  events.value.filter((item) => {
    const startDateIsAfterMinDate = moment(item.startDate).isSameOrAfter(
      date.value[0],
      "day"
    );
    const endDateIsBeforeMaxDate = moment(item.endDate).isSameOrBefore(
      date.value[1],
      "day"
    );
    return startDateIsAfterMinDate && endDateIsBeforeMaxDate;
  })
);

let eventNo = 0;
const arrDate = ref([]);
let arrRef = [];
const diffDate = () => {
  const difData = moment(date.value[1]).diff(moment(date.value[0]), "days") + 1;
  console.log(difData);
  arrDate.value = [];
  const start = moment(date.value[0]);
  while (start.isSameOrBefore(date.value[1])) {
    arrDate.value.push({
      date: start.format("YYYY-MM-DD"),
      event: events.value
        .filter((item) =>
          moment(new Date(item.startDate))
            .utc()
            .startOf("day")
            .isSame(moment(start), "day")
        )
        .sort((a, b) => {
          return new Date(a.startDate) - new Date(b.startDate);
        }),
    });
    start.add(1, "days");
  }
  console.log(arrDate.value);
  arrRef = arrDate.value.map(() => 0);
  return difData;
};

const eventHad = (item, time, index) => {
  const currentdate = new Date(item.event[arrRef[index]]?.startDate);
  const hour = currentdate.getUTCHours();
  if (hour === time.value) {
    const val = arrRef[index];
    arrRef[index] = val + 1;
    return val;
  } else {
    return null;
  }
};

const allEvents = ref(false);
const eventsValues = ref([
  {
    label: "Estimator 1",
    checked: true,
    classnew: "EstimatorOne",
    backgroundColor: "#9FC0FF",
  },
  {
    label: "Estimator 2",

    classnew: "EstimatorTwo",
    backgroundColor: "#C0FFB5",
  },
  {
    label: "Estimator 3",

    classnew: "Estimatorthree",
    backgroundColor: "#00FFFF",
  },
  {
    label: "Estimator 4",

    classnew: "EstimatorFour",
    backgroundColor: "#FFF975",
  },
]);
watch(
  eventsValues,
  (newEventsValues) => {
    eventNo = 0;
    dynEvents.value = events.value.filter(
      (item) =>
        eventsValues.value.find((event) => event.label === item.category)
          ?.checked
    );
    dynEvents.value = dynEvents.value.filter((item) => {
      const startDateIsAfterMinDate = moment(item.startDate).isSameOrAfter(
        date.value[0],
        "day"
      );
      const endDateIsBeforeMaxDate = moment(item.endDate).isSameOrBefore(
        date.value[1],
        "day"
      );
      return startDateIsAfterMinDate && endDateIsBeforeMaxDate;
    });
  },
  { deep: true }
);
watch(date, (newDate) => {
  eventNo = 0;
  dynEvents.value = events.value.filter((item) => {
    const startDateIsAfterMinDate = moment(item.startDate).isSameOrAfter(
      newDate[0],
      "day"
    );
    const endDateIsBeforeMaxDate = moment(item.endDate).isSameOrBefore(
      newDate[1],
      "day"
    );
    return startDateIsAfterMinDate && endDateIsBeforeMaxDate;
  });
});
watch(selectedDuration, (newSelectedDuration) => {
  eventNo = 0;
  const newEndDate = moment(date.value[0]).add(newSelectedDuration, "weeks");
  date.value = [
    moment(todayDate).day(0),
    newEndDate.subtract(1, "day").toDate(),
  ];
});
watch(allEvents, (newAllEvents) => {
  eventId = 0;
  if (allEvents.value === true) {
    dynEvents.value = events.value.filter((item) => {
      const startDateIsAfterMinDate = moment(item.startDate).isSameOrAfter(
        date.value[0],
        "day"
      );
      const endDateIsBeforeMaxDate = moment(item.endDate).isSameOrBefore(
        date.value[1],
        "day"
      );
      return startDateIsAfterMinDate && endDateIsBeforeMaxDate;
    });
    eventsValues.value = eventsValues.value.map((item) => ({
      ...item,
      checked: true,
    }));
    eventNo = 0;
  } else {
    dynEvents.value = [];
    eventsValues.value = eventsValues.value.map((item) => ({
      ...item,
      checked: false,
    }));
    eventNo = 0;
  }
});
watch(isSaturdayClosed, (newIsSaturdayClosed) => {
  eventId = 0;
  dynEvents.value = dynEvents.value.filter(
    (item) => moment(item.startDate).format("dddd") !== "Saturday"
  );
  eventNo = 0;
});
watch(isSundayClosed, (newIsSundayClosed) => {
  eventId = 0;
  dynEvents.value = dynEvents.value.filter(
    (item) => moment(item.startDate).format("dddd") !== "Sunday"
  );
  eventNo = 0;
});
</script>
<template>
  <div class="row mt-4">
    <div class="col-sm-3">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <p class="m-0 est">EST</p>
        <select
          class="form-select mb-2 w-50"
          aria-label="small select example"
          v-model="selectedDuration"
        >
          <option value="1">1 Week</option>
          <option value="2">2 Weeks</option>
        </select>
      </div>

      <VueDatePicker v-model="date" inline model-auto range week-start="0" />
      <div class="card mt-2">
        <div
          class="card-body"
          :style="{ boxShadow: '0px 3.297px 3.297px 0px rgba(0, 0, 0, 0.25)' }"
        >
          <h6 class="mb-2">Shop Closed</h6>
          <label class="datelableaAq" style="margin-bottom: 2px;">
            <input type="checkbox" v-model="isSaturdayClosed" />
            Saturday
          </label>
          <label class="datelableaAq">
            <input type="checkbox" v-model="isSundayClosed" />
            Sunday
          </label>
        </div>
      </div>
      <div class="mt-5 d-flex align-items-center justify-content-start gap-2">
        <h6 class="m-0">Estimator</h6>
        <img :src="Estim" alt="Estim" />
      </div>
      <div class="mt-3">
        <label
          v-for="(item, index) in eventsValues"
          :key="index"
          class="datelableaAq"
          :style="{ marginBottom: '10px' }"
          :class="item.classnew"
        >
          <input type="checkbox" v-model="eventsValues[index].checked" />
          <span class="dataNuAx">3</span> {{ item.label }}
        </label>
      </div>
    </div>
    <div class="col-sm-9">
      <div class="d-flex justify-content-end">
        <div class="input-container w-25">
          <div class="input-group flex-nowrap">
            <input
              class="form-control border"
              type="search"
              id="example-search-input"
              placeholder="VIN, RO, Last Name, Cell, Cust ID"
            />
            <span class="input-group-append">
              <button
                class="btn btn-outline-secondary bg-white border-start-0 border-bottom-0 border ms-n5"
                type="button"
              >
                <i class="fa fa-search"></i>
              </button>
            </span>
          </div>
        </div>
      </div>

      <div class="col mt-3" style="position: relative;">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th></th>
                <th v-for="index in diffDate()" :key="index">
                  <div
                    style="
                      text-align: center;
                      font-size: small;
                      text-decoration: none;
                    "
                  >
                    {{
                      moment(date[0])
                        .add(index - 1, "days")
                        .format("dddd")
                    }}
                  </div>
                  <div style="text-align: center; font-size: xx-large;">
                    {{
                      moment(date[0])
                        .add(index - 1, "days")
                        .format("D")
                    }}
                  </div>
                  <input
                    type="checkbox"
                    v-if="index === 1 || index === 8"
                    v-model="isSundayClosed"
                  />
                  <input
                    type="checkbox"
                    v-else-if="index === 7 || index === 14"
                    v-model="isSaturdayClosed"
                  />
                  <input v-else type="checkbox" />
                </th>
              </tr>
            </thead>
            <tbody></tbody>
            <tbody>
              <tr v-for="time in timeArray" :key="time.value">
                <td style="width: 35px; white-space: nowrap;">
                  {{ time.value > 12 ? time.value - 12 : time.value }}
                  {{ time.value >= 12 ? "PM" : "AM" }}
                </td>
                <template v-for="(item, index) in arrDate">
                  <td
                    v-if="item?.event[eventHad(item, time, index)]"
                    :style="{
                      background:
                        item?.event[arrRef[index] - 1]?.backgroundColor,
                    }"
                    style="width: 132px; font-size: xx-small;"
                  >
                    {{ item?.event[arrRef[index] - 1].id
                    }}{{ item?.event[arrRef[index] - 1].folder }}
                    {{ item?.event[arrRef[index] - 1].insurance
                    }}{{ item?.event[arrRef[index] - 1].name }}
                    {{ item?.event[arrRef[index] - 1].date }}
                    {{ item?.event[arrRef[index] - 1].body }}
                    {{ item?.event[arrRef[index] - 1].category }}
                  </td>
                  <td v-else style="width: 132px; height: 100px;"></td>
                </template>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dp__outer_menu_wrap {
  width: 100%;
}

.fc-scroller {
  overflow-y: scroll !important;
}

.est {
  border: 1px solid #eee;
  border-radius: 5px;
  padding: 2px 15px;
}

.datelableaAq {
  display: flex;
  align-items: center;
  gap: 15px;
}
input#example-search-input::placeholder {
  font-size: 11px;
}
.dataNuAx {
  border-radius: 3.876px;
  border: 0.775px solid #eee;
  background: #eee;
  padding: 1px 7px;
  font-size: 11px;
  font-weight: 500;
}

.datelableaAq input {
  width: 20px;
  height: 20px;
  padding: 5px;
}

.EstimatorOne input {
  accent-color: #9fc0ff;
}

.EstimatorTwo input {
  accent-color: #c0ffb5;
}

.Estimatorthree input {
  accent-color: #00ffff;
}

.EstimatorFour input {
  accent-color: #fff975;
}

#eventContainer {
  position: relative;
}

.eventPopup {
  position: absolute;
  z-index: 10;
  padding: 1rem;
  background-color: #ffffff;
  border: 1px solid #d2d6dc;
  border-radius: 0.375rem;
  top: 0;
  left: 0;
}

.eventHeader {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 1rem;
  border-bottom: 1px solid #d2d6dc;
}

.eventTitle {
  font-size: 1rem;
}

.eventBody {
  background-color: #a4b0be;
  border-radius: 0 0 6px 6px;
  padding: 1rem;
}

#editor {
  width: 100%;
  box-sizing: border-box;
  padding: 0.5rem;
  font-size: 0.875rem;
  background-color: #a4b0be;
  border: 1px solid #d2d6dc;
  border-radius: 0.375rem;
  margin-bottom: 1rem;
}

#addEvent {
  background-color: #1a4a72;
  color: #ffffff;
  font-size: 0.875rem;
  padding: 0.625rem 1.25rem;
  border: none;
  border-radius: 0.375rem;
  cursor: pointer;
}

#addEvent:hover {
  background-color: #2b6cb0;
}
</style>
